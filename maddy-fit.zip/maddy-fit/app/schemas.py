import re
from datetime import datetime
from pydantic import BaseModel, EmailStr, Field, field_validator

class SignupIn(BaseModel):
    name: str = Field(min_length=2, max_length=60)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)

    @field_validator("name")
    @classmethod
    def clean_name(cls, v):
        v = v.strip()
        if not re.fullmatch(r"[A-Za-z0-9 .'-]{2,60}", v):
            raise ValueError("Name can use letters, numbers, spaces, . ' -")
        return v

    @field_validator("password")
    @classmethod
    def strong_password(cls, v):
        if not (re.search(r"[A-Za-z]", v) and re.search(r"\d", v)):
            raise ValueError("Password needs at least one letter and one number")
        return v

class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=72)

class UserOut(BaseModel):
    id: int
    name: str
    email: EmailStr
    role: str
    model_config = {"from_attributes": True}

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut

class WorkoutIn(BaseModel):
    activity: str = Field(min_length=2, max_length=80)
    minutes: int = Field(ge=1, le=600)
    calories: int = Field(ge=0, le=5000)

class WorkoutOut(WorkoutIn):
    id: int
    created_at: datetime
    model_config = {"from_attributes": True}
