import os
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select
from sqlalchemy.orm import Session
from .database import Base, engine, get_db
from .models import User, Workout
from .schemas import *
from .security import hash_password, verify_password, create_token, current_user, admin_only

Base.metadata.create_all(engine)
app = FastAPI(title="Maddy Fit API")
ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "").lower()

# ---------- Auth ----------
@app.post("/api/signup", response_model=TokenOut, status_code=201)
def signup(body: SignupIn, db: Session = Depends(get_db)):
    email = body.email.lower()
    if db.scalar(select(User).where(User.email == email)):  # parameterized query
        raise HTTPException(409, "That email is already registered")
    role = "admin" if email == ADMIN_EMAIL else "user"
    user = User(name=body.name, email=email, password_hash=hash_password(body.password), role=role)
    db.add(user); db.commit(); db.refresh(user)
    return TokenOut(access_token=create_token(user), user=user)

@app.post("/api/login", response_model=TokenOut)
def login(body: LoginIn, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == body.email.lower()))
    if not user or not verify_password(body.password, user.password_hash):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Email or password is incorrect")
    return TokenOut(access_token=create_token(user), user=user)

@app.get("/api/me", response_model=UserOut)
def me(user: User = Depends(current_user)):
    return user

# ---------- Workouts (business logic: users only touch their own) ----------
@app.post("/api/workouts", response_model=WorkoutOut, status_code=201)
def add_workout(body: WorkoutIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    w = Workout(user_id=user.id, **body.model_dump())
    db.add(w); db.commit(); db.refresh(w)
    return w

@app.get("/api/workouts", response_model=list[WorkoutOut])
def my_workouts(user: User = Depends(current_user), db: Session = Depends(get_db)):
    q = select(Workout).where(Workout.user_id == user.id).order_by(Workout.created_at.desc())
    return db.scalars(q).all()

@app.delete("/api/workouts/{wid}", status_code=204)
def delete_workout(wid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    w = db.get(Workout, wid)
    if not w or w.user_id != user.id:
        raise HTTPException(404, "Workout not found")
    db.delete(w); db.commit()

# ---------- Admin ----------
@app.get("/api/users", response_model=list[UserOut])
def list_users(_: User = Depends(admin_only), db: Session = Depends(get_db)):
    return db.scalars(select(User).order_by(User.id)).all()

@app.delete("/api/users/{uid}", status_code=204)
def delete_user(uid: int, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    if uid == admin.id:
        raise HTTPException(400, "You can't delete your own account")
    target = db.get(User, uid)
    if not target:
        raise HTTPException(404, "User not found")
    db.delete(target); db.commit()

# ---------- Frontend ----------
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
def home():
    return FileResponse("static/index.html")
