# Maddy Fit

FastAPI + MySQL backend, plain HTML/CSS/JS frontend.

## Run locally
1. `python -m venv venv && source venv/bin/activate` (Windows: `venv\Scripts\activate`)
2. `pip install -r requirements.txt`
3. In MySQL: `CREATE DATABASE maddyfit CHARACTER SET utf8mb4;` and create a user with access to it.
4. `cp .env.example .env` and fill in DATABASE_URL, SECRET_KEY, ADMIN_EMAIL.
   Generate a key: `python -c "import secrets; print(secrets.token_urlsafe(48))"`
5. `uvicorn app.main:app --reload` then open http://127.0.0.1:8000
   (API docs at /docs)

The account that signs up with ADMIN_EMAIL becomes the admin.
