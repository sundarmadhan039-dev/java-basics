const $ = (id) => document.getElementById(id);
let mode = "login";
let token = sessionStorage.getItem("token");

async function api(path, method = "GET", body) {
  const res = await fetch("/api" + path, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    let msg = data.detail;
    if (Array.isArray(msg)) msg = msg.map((e) => e.msg.replace("Value error, ", "")).join(". ");
    throw new Error(msg || "Something went wrong");
  }
  return data;
}

function setMode(m) {
  mode = m;
  const signup = m === "signup";
  $("tab-login").classList.toggle("on", !signup);
  $("tab-signup").classList.toggle("on", signup);
  $("signup-name-wrap").hidden = !signup;
  $("pw-hint").hidden = !signup;
  $("auth-btn").textContent = signup ? "Create account" : "Log in";
  $("auth-msg").textContent = "";
}

function li(text, onDelete) {
  const el = document.createElement("li");
  const span = document.createElement("span");
  span.textContent = text;           // textContent prevents XSS
  el.append(span);
  if (onDelete) {
    const b = document.createElement("button");
    b.textContent = "Delete";
    b.onclick = onDelete;
    el.append(b);
  }
  return el;
}

async function loadWorkouts() {
  const items = await api("/workouts");
  const ul = $("workouts");
  ul.replaceChildren();
  if (!items.length) ul.append(li("No workouts yet. Log your first one above."));
  items.forEach((w) =>
    ul.append(li(`${w.activity}: ${w.minutes} min, ${w.calories} kcal`, async () => {
      await api("/workouts/" + w.id, "DELETE");
      loadWorkouts();
    }))
  );
}

async function loadUsers(me) {
  const users = await api("/users");
  const ul = $("users");
  ul.replaceChildren();
  users.forEach((u) =>
    ul.append(li(`${u.name} (${u.email}) · ${u.role}`, u.id === me.id ? null : async () => {
      if (!confirm("Delete " + u.name + "?")) return;
      await api("/users/" + u.id, "DELETE");
      loadUsers(me);
    }))
  );
}

async function showApp(user) {
  $("auth").hidden = true;
  $("app").hidden = false;
  $("logout").hidden = false;
  $("welcome").textContent = "Hi, " + user.name;
  $("admin").hidden = user.role !== "admin";
  await loadWorkouts();
  if (user.role === "admin") await loadUsers(user);
}

function showAuth() {
  token = null;
  sessionStorage.removeItem("token");
  $("auth").hidden = false;
  $("app").hidden = true;
  $("logout").hidden = true;
}

$("tab-login").onclick = () => setMode("login");
$("tab-signup").onclick = () => setMode("signup");

$("auth-btn").onclick = async () => {
  $("auth-msg").textContent = "";
  try {
    const payload = { email: $("email").value, password: $("password").value };
    if (mode === "signup") payload.name = $("name").value;
    const data = await api(mode === "signup" ? "/signup" : "/login", "POST", payload);
    token = data.access_token;
    sessionStorage.setItem("token", token);
    $("password").value = "";
    showApp(data.user);
  } catch (e) {
    $("auth-msg").textContent = e.message;
  }
};

$("add-workout").onclick = async () => {
  $("w-msg").textContent = "";
  try {
    await api("/workouts", "POST", {
      activity: $("activity").value,
      minutes: parseInt($("minutes").value, 10),
      calories: parseInt($("calories").value, 10),
    });
    ["activity", "minutes", "calories"].forEach((id) => ($(id).value = ""));
    loadWorkouts();
  } catch (e) {
    $("w-msg").textContent = e.message;
  }
};

$("logout").onclick = showAuth;

(async () => {
  if (!token) return;
  try { showApp(await api("/me")); } catch { showAuth(); }
})();
